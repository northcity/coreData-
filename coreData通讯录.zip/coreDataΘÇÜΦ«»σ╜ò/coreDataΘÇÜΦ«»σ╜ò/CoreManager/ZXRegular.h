//
//  ZXRegular.h
//  coreData通讯录
//
//  Created by chenxi on 2017/6/23.
//  Copyright © 2017年 chenxi. All rights reserved.
//

#import <Foundation/Foundation.h>
//正则验证
@interface ZxkRegular : NSObject

+ (BOOL)regularEmail:(NSString *)string;

+ (BOOL)regularPhone:(NSString *)string;

+ (BOOL)regularFloatNumber:(NSString *)string;

@end
