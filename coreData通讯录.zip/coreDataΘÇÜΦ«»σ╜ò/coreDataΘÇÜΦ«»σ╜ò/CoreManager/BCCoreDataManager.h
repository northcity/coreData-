//
//  BCCoreDataManager.h
//  coreData通讯录
//
//  Created by chenxi on 2017/6/23.
//  Copyright © 2017年 chenxi. All rights reserved.
//

#import <Foundation/Foundation.h>

//导入CoreData框架
#import <CoreData/CoreData.h>

#define kBCCoreDataManager [BCCoreDataManager shareInstance]


@interface BCCoreDataManager : NSObject

//数据管理单利
+ (BCCoreDataManager *)shareInstance;

//管理对象上下文
@property(nonatomic,strong)NSManagedObjectContext *managedObjectContext;

//模型对象
@property(nonatomic,strong)NSManagedObjectModel *managedObjectModel;

//存储调度器
@property(nonatomic,strong)NSPersistentStoreCoordinator *persistentStoreCoordinator;

//保存
- (void)save;
@end

