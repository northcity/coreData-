//
//  Contact+CoreDataClass.h
//  coreData通讯录
//
//  Created by chenxi on 2017/6/23.
//  Copyright © 2017年 chenxi. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

NS_ASSUME_NONNULL_BEGIN

@interface Contact : NSManagedObject

@end

NS_ASSUME_NONNULL_END

#import "Contact+CoreDataProperties.h"
