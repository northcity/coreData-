//
//  CoreDataTool.h
//  通讯录
//
//  Created by hm04 on 16/9/26.
//  Copyright © 2016年 hm04. All rights reserved.
//

#ifndef CoreDataTool_h
#define CoreDataTool_h

#import "BCCoreDataManager.h"

#import "ZXRegular.h"

#import "Contact+CoreDataProperties.h"

#import "CommonTool.h"


#endif /* CoreDataTool_h */
