//
//  Contact+CoreDataProperties.h
//  coreData通讯录
//
//  Created by chenxi on 2017/6/23.
//  Copyright © 2017年 chenxi. All rights reserved.
//

#import "Contact+CoreDataClass.h"


NS_ASSUME_NONNULL_BEGIN

@interface Contact (CoreDataProperties)

+ (NSFetchRequest<Contact *> *)fetchRequest;

@property (nullable, nonatomic, copy) NSString *name;
@property (nullable, nonatomic, copy) NSString *namePinYin;
@property (nullable, nonatomic, copy) NSString *phoneNum;
@property (nullable, nonatomic, copy) NSString *sectionName;

@end

NS_ASSUME_NONNULL_END
