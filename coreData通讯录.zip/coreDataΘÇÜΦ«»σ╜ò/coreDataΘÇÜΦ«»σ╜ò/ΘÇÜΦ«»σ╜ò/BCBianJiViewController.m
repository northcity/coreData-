//
//  BCBianJiViewController.m
//  coreData通讯录
//
//  Created by chenxi on 2017/6/23.
//  Copyright © 2017年 chenxi. All rights reserved.
//

#import "BCBianJiViewController.h"
#import "ZXRegular.h"
#import "CommonTool.h"
#import "CoreDataTool.h"

@interface BCBianJiViewController ()
@property (weak, nonatomic) IBOutlet UITextField *nameTextFile;
@property (weak, nonatomic) IBOutlet UITextField *phoneNumTextFIle;


@end

@implementation BCBianJiViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.nameTextFile.text = self.contact.name;
    self.phoneNumTextFIle.text = self.contact.phoneNum;
    self.title = self.contact.name;
}

- (IBAction)saveBtn:(id)sender {
    
    
    if ([self checkTextField] == NO) {
        return;
    }
    
    self.contact.name = self.nameTextFile.text;
    self.contact.phoneNum = self.phoneNumTextFIle.text;
    
    self.contact.namePinYin = [CommonTool getPinYinFromString:self.nameTextFile.text];
    //分组信息
    self.contact.sectionName = [[self.contact.namePinYin substringFromIndex:1]uppercaseString];
    
    ///保存数据后，返回到原来的控制器
    [kBCCoreDataManager save];
    
    [self.navigationController popViewControllerAnimated:YES];

}

- (IBAction)cancelBtn:(id)sender {

    [self.navigationController popViewControllerAnimated:YES];

}


-(BOOL)checkTextField
{
    if(self.nameTextFile.text.length == 0)
    {
        UIAlertController *c = [UIAlertController alertControllerWithTitle:@"提示" message:@"姓名不能为空" preferredStyle:UIAlertControllerStyleAlert];
        [c addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:nil]];
        [self presentViewController:c animated:YES completion:nil];
        return NO;
    }
    else if ([ZxkRegular regularPhone:self.phoneNumTextFIle.text] == NO)
    {
        UIAlertController *c = [UIAlertController alertControllerWithTitle:@"提示" message:@"手机号格式错误" preferredStyle:UIAlertControllerStyleAlert];
        [c addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:nil]];
        [self presentViewController:c animated:YES completion:nil];
        return NO;
    }
    else
        return YES;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
