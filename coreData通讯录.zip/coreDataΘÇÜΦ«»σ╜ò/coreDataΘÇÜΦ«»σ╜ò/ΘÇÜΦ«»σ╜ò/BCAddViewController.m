//
//  BCAddViewController.m
//  coreData通讯录
//
//  Created by chenxi on 2017/6/23.
//  Copyright © 2017年 chenxi. All rights reserved.
//

#import "BCAddViewController.h"
#import "Contact+CoreDataProperties.h"
#import "CoreDataTool.h"

@interface BCAddViewController ()
@property (weak, nonatomic) IBOutlet UITextField *nameText;

@property (weak, nonatomic) IBOutlet UITextField *phineNum;

@end

@implementation BCAddViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}
- (IBAction)cancelButton:(id)sender {
    
    //返回原来的界面
    [self.navigationController popViewControllerAnimated:YES];
}
- (IBAction)updateContact:(id)sender {
    
    
    if ([self checkTextField] == NO) {
        return;
    }
    
    //创建一个模型对象
    Contact *tanct = [NSEntityDescription insertNewObjectForEntityForName:@"Contact" inManagedObjectContext:kBCCoreDataManager.managedObjectContext];
    
    tanct.name = self.nameText.text;
    tanct.phoneNum = self.phineNum.text;
    tanct.namePinYin = [CommonTool getPinYinFromString:tanct.name];
    tanct.sectionName = [[tanct.namePinYin substringFromIndex:1] uppercaseString];
    
    [kBCCoreDataManager save];
    
    [self.navigationController popViewControllerAnimated:YES];
    

}

-(BOOL)checkTextField
{
    if(self.nameText.text.length == 0)
    {
        UIAlertController *c = [UIAlertController alertControllerWithTitle:@"提示" message:@"姓名不能为空" preferredStyle:UIAlertControllerStyleAlert];
        [c addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:nil]];
        [self presentViewController:c animated:YES completion:nil];
        return NO;
    }
    else if ([ZxkRegular regularPhone:self.phineNum.text] == NO)
    {
        UIAlertController *c = [UIAlertController alertControllerWithTitle:@"提示" message:@"手机号格式错误" preferredStyle:UIAlertControllerStyleAlert];
        [c addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:nil]];
        [self presentViewController:c animated:YES completion:nil];
        return NO;
    }
    else
        return YES;
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
