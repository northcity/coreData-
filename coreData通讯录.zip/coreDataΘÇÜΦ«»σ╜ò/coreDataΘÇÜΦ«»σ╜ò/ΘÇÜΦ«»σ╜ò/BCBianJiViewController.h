//
//  BCBianJiViewController.h
//  coreData通讯录
//
//  Created by chenxi on 2017/6/23.
//  Copyright © 2017年 chenxi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Contact+CoreDataProperties.h"

@interface BCBianJiViewController : UIViewController

@property(strong,nonatomic) Contact* contact;


@end
