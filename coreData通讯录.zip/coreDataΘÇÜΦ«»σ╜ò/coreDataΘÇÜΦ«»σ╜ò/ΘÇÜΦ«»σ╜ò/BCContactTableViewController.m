//
//  BCContactTableViewController.m
//  coreData通讯录
//
//  Created by chenxi on 2017/6/23.
//  Copyright © 2017年 chenxi. All rights reserved.
//

#import "BCContactTableViewController.h"
#import "CommonTool.h"
#import "CoreDataTool.h"
#import "BCBianJiViewController.h"
#import "BCAddViewController.h"

@interface BCContactTableViewController ()<NSFetchedResultsControllerDelegate,UISearchBarDelegate>

@property(strong,nonatomic)NSFetchedResultsController *fetchedResultsController;

@property(nonatomic,strong)NSMutableArray *dataSource, *dataBase;
//是否删除
@property(assign,nonatomic)BOOL isTrash;

@end

@implementation BCContactTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    NSLog(@"沙盒地址===%@",NSHomeDirectory());
    [self fetchedResultsController];
    [self addSearchBar];
    
    self.tableView = [[UITableView alloc]initWithFrame:self.view.bounds style:UITableViewStylePlain];
    [self.tableView  registerClass:[UITableViewCell class] forCellReuseIdentifier:@"cell"];
    
    //改变索引的颜色
    self.tableView.sectionIndexColor = [UIColor blueColor];
    //改变索引选中的背景颜色
    self.tableView.sectionIndexTrackingBackgroundColor = [UIColor grayColor];
    
    //索引数组
    _dataSource = [[NSMutableArray alloc] init] ;
    
    //tableview 数据源
    _dataBase = [[NSMutableArray alloc] init] ;
    
    //初始化数据
    for(char c = 'A'; c <= 'Z'; c++ )
    {
        [_dataSource addObject:[NSString stringWithFormat:@"%c",c]];
        [_dataBase addObject:[NSString stringWithFormat:@"%c",c]];
        [_dataBase addObject:[NSString stringWithFormat:@"%c",c]];
        [_dataBase addObject:[NSString stringWithFormat:@"%c",c]];
    }
}

//返回索引数组
-(NSArray *)sectionIndexTitlesForTableView:(UITableView *)tableView
{
    return _dataSource;
}

//响应点击索引时的委托方法
-(NSInteger)tableView:(UITableView *)tableView sectionForSectionIndexTitle:(NSString *)title atIndex:(NSInteger)index
{
    NSInteger count = 0;
    
    NSLog(@"%@-%ld",title,(long)index);
    
    for(NSString *character in _dataSource)
    {
        if([character isEqualToString:title])
        {
            return count;
        }
        count ++;
    }
    return 0;
}



-(UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return UITableViewCellEditingStyleDelete | UITableViewCellEditingStyleInsert;
}

-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    
    
    //取消选中的cell
    NSArray * indexPaths = [self.tableView indexPathsForSelectedRows];
    
    for(NSIndexPath * indexPath in indexPaths)
    {
        [self.tableView deselectRowAtIndexPath:indexPath animated:YES];
    }
}

///添加搜索栏
-(void)addSearchBar
{
    UIButton *buttonLeft = [UIButton buttonWithType:UIButtonTypeSystem];
    buttonLeft.frame = CGRectMake(10, 10, 44, 44);
//    buttonLeft.backgroundColor = [UIColor redColor];
//    [buttonLeft setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];

//    [buttonLeft setTitle:@"删除" forState:UIControlStateNormal];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithCustomView:buttonLeft];
    [buttonLeft addTarget:self action:@selector(trashData:) forControlEvents:UIControlEventTouchUpInside];
  
    
    [buttonLeft setBackgroundImage:[UIImage imageNamed:@"删除"] forState:UIControlStateNormal];

    UIButton *buttonRight = [UIButton buttonWithType:UIButtonTypeCustom];
    buttonRight.frame = CGRectMake(self.view.frame.size.width-55, 10, 44, 44);
//    buttonRight.backgroundColor = [UIColor redColor];
//    [buttonRight setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
//    [buttonRight setTitle:@"添加" forState:UIControlStateNormal];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]initWithCustomView:buttonRight];
    [buttonRight addTarget:self action:@selector(push) forControlEvents:UIControlEventTouchUpInside];
    [buttonRight setBackgroundImage:[UIImage imageNamed:@"添加"] forState:UIControlStateNormal];

    
    UISearchBar *searchBar = [[UISearchBar alloc]initWithFrame:CGRectMake(30, 0, self.view.frame.size.width-60, 44)];
    searchBar.delegate = self;
    self.navigationItem.titleView = searchBar;
    searchBar.showsBookmarkButton =YES;

}

- (void)push{
    BCAddViewController * bc = [[BCAddViewController alloc]init];
    [self.navigationController pushViewController:bc animated:YES];
}

//实现搜索功能
-(void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
    //文本框内容发生改变的时候调用该方法
    searchText = [[CommonTool getPinYinFromString:searchText]lowercaseString];
    
    ///有文字的时候添加谓词
    if (searchText.length > 0) {
        
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"self.name CONTAINS %@ || self.namePinYin CONTAINS %@ || self.phoneNum CONTAINS %@",searchText,searchText,searchText];
        
        self.fetchedResultsController.fetchRequest.predicate = predicate;
    }else{
        self.fetchedResultsController.fetchRequest.predicate = nil;
    }
    
    ///文字改变的时候就马上执行查询，用户不需要点击搜索按钮就能进行搜索
    
    [self.fetchedResultsController performFetch:nil];
    ///刷新界面
    [self.tableView reloadData];
}

-(NSFetchedResultsController *)fetchedResultsController
{
    if (_fetchedResultsController != nil) {
        return _fetchedResultsController;
    }
    
    // set your fetch request, entity, predicate, sort descriptors etc.
    
    
    
    ///创建请求
    NSFetchRequest *request = [[NSFetchRequest alloc]initWithEntityName:@"Contact"];
    ///设置请求排序器
    request.sortDescriptors = @[[NSSortDescriptor sortDescriptorWithKey:@"namePinYin" ascending:YES]];

        self.fetchedResultsController = [[NSFetchedResultsController alloc]initWithFetchRequest:request managedObjectContext:kBCCoreDataManager.managedObjectContext sectionNameKeyPath:@"sectionName" cacheName:nil];
  
    
   
//    NSFetchedResultsController *aController = [[NSFetchedResultsController alloc]
//                                               initWithFetchRequest:request
//                                               managedObjectContext:kBCCoreDataManager.managedObjectContext
//                                               sectionNameKeyPath:@"sectionName"
//                                               cacheName:nil];
//    
//    NSError *error;
//    aController.delegate = self;
//    
//    [aController performFetch:&error];
//    _fetchedResultsController = aController;
    
    _fetchedResultsController.delegate = self;
    
    ///执行查询
    [_fetchedResultsController performFetch:nil];
    
    [self.tableView reloadData];
    
    return _fetchedResultsController;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    if (self.isTrash == YES) {
        return 0;
    }else{
        return self.fetchedResultsController.sections.count;
    }
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    id <NSFetchedResultsSectionInfo> info = self.fetchedResultsController.sections[section];
    return [info numberOfObjects];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    ///获取到对象
    if (_isTrash == NO) {
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
        
        //获取模型
        Contact *contact = [_fetchedResultsController objectAtIndexPath:indexPath];
        cell.textLabel.text = contact.name;
        cell.detailTextLabel.text = contact.phoneNum;
        
        return cell;
    }else{
        
        return nil;
    }
    
}
//添加删除功能
- (nullable NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    return self.fetchedResultsController.sectionIndexTitles[section];
}

-(BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}

-(NSString *)tableView:(UITableView *)tableView titleForDeleteConfirmationButtonForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return @"删除";
}

///通过下标获取到要删除的文件
-(void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    ///获取index
    Contact *contact = [self.fetchedResultsController objectAtIndexPath:indexPath];
    ///删除数据
    [kBCCoreDataManager.managedObjectContext deleteObject:contact];
    
    [kBCCoreDataManager save];
}

#pragma mark -NSFetchedResultsControllerDelegate

- (void)controller:(NSFetchedResultsController *)controller didChangeObject:(id)anObject atIndexPath:(nullable NSIndexPath *)indexPath forChangeType:(NSFetchedResultsChangeType)type newIndexPath:(nullable NSIndexPath *)newIndexPath
{
    ///获取当前tableView组的数量
    NSInteger sectionNum = self.tableView.numberOfSections;
    
    //获取NSFetchedResultsController组的数量,如果和tableView组的数量不相等，就表示有新的数据插入
    NSInteger fetchSection = self.fetchedResultsController.sections.count;
    
    switch (type) {
        case NSFetchedResultsChangeInsert:
            
            //插入数据
            [self.tableView beginUpdates];
            if (sectionNum != fetchSection) {
                [self.tableView insertSections:[NSIndexSet indexSetWithIndex:newIndexPath.section] withRowAnimation:UITableViewRowAnimationMiddle];
            }else{
                [self.tableView insertRowsAtIndexPaths:@[newIndexPath] withRowAnimation:UITableViewRowAnimationMiddle];
            }
            [self.tableView reloadData];
            ///tableView有开始更新，就有结束更新
            ///不能没有结束更新
            [self.tableView endUpdates];
            break;
            
        case NSFetchedResultsChangeDelete:
            [self.tableView beginUpdates];
            if (sectionNum != fetchSection) {
                [self.tableView deleteSections:[NSIndexSet indexSetWithIndex:indexPath.section] withRowAnimation:UITableViewRowAnimationMiddle];
            }else{
                [self.tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationMiddle];
            }
            [self.tableView endUpdates];
            break;
            
        case NSFetchedResultsChangeMove:
            [self.tableView reloadData];
            break;
            
        case NSFetchedResultsChangeUpdate:
            //刷新数据
            [self.tableView beginUpdates];
            [self.tableView reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationMiddle];
            [self.tableView endUpdates];
            break;
            
        default:
            break;
    }
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    BCBianJiViewController *ediVC = [[BCBianJiViewController alloc]init];
    
    Contact *contact = [self.fetchedResultsController objectAtIndexPath:indexPath];
    ediVC.contact = contact;
    [self.navigationController pushViewController:ediVC animated:YES];
}
///跳转控制器
-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
//    添加控制器
    if ([segue.identifier isEqualToString:@"BCBianJiViewController"]) {
        
        BCBianJiViewController *ediVC = (BCBianJiViewController *)[segue destinationViewController];
        NSIndexPath *indexPath = [self.tableView indexPathForSelectedRow];
        
        Contact *contact = [self.fetchedResultsController objectAtIndexPath:indexPath];
        ediVC.contact = contact;
    }
    
}

- (IBAction)trashData:(id)sender {

    ///删除文件的方法

    NSBatchDeleteRequest *batchRequest = [[NSBatchDeleteRequest alloc]initWithFetchRequest:[[NSFetchRequest alloc]initWithEntityName:@"Contact"]];
    //执行批量删除文件的请求
    [kBCCoreDataManager.persistentStoreCoordinator executeRequest:batchRequest withContext:kBCCoreDataManager.managedObjectContext error:nil];
    self.fetchedResultsController = nil;

    [self.tableView reloadData];
}


@end
